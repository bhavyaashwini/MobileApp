import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { AdminadddetailsComponent } from './adminadddetails/adminadddetails.component';
import { ChatInboxComponent } from './chat-inbox/chat-inbox.component';
import { HomepageComponent } from './homepage/homepage.component';
import { SignupComponent } from './signup/signup.component';
import { SmsNotificationComponent } from './sms-notification/sms-notification.component';
import { UserdashboardComponent } from './userdashboard/userdashboard.component';

const routes: Routes = [


  {
    path:'',
    redirectTo:'homepage',
    pathMatch:'full'
      },

      {
        path:'homepage',
        component:HomepageComponent
      },
      {
        path:'signup',
        component:SignupComponent
        
      },
      {
        path:'admin',
        component:AdminComponent
      },
      {
        path:'user',
        component:UserdashboardComponent
      },
      {
        path:'adddetails',
        component:AdminadddetailsComponent
      },
      {
        path:'chatinbox',
        component:ChatInboxComponent
      },
      {
        path:'sms',
        component:SmsNotificationComponent
      }

      




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
