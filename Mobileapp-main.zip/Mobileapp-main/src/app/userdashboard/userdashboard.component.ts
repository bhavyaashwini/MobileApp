import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';
import io from "socket.io-client";

import { chat } from '../supportts';
var socket = io('http://localhost:3000/', { transports : ['websocket'] });
@Component({
  selector: 'app-userdashboard',
  templateUrl: './userdashboard.component.html',
  styleUrls: ['./userdashboard.component.css']
})
export class UserdashboardComponent implements OnInit {
  chats: any;
  joinned: boolean = false;
  newUser = { nickname: '', room: '' };
  msgData = { room: '', nickname: '', message: '' };
  socket : any;
  

  msg: chat = {
    message: '',
    _id:''
    
  };

  constructor(private webSocketService: MyserviceService) {}
 ngOnInit(){
   
 }
  scrollToBottom(): void {}
  getChatByRoom() {
   this.webSocketService.getChatByRoom().subscribe(
     data => {
       this.chats= data;
       console.log("data", data);
     },
     error=> {

      console.log(error);
     }
   )
  }
  
  
  joinRoom() {
    var date = new Date();
    localStorage.setItem("user", JSON.stringify(this.newUser));
    this.getChatByRoom();
    this.msgData = { room: this.newUser.room, nickname: this.newUser.nickname, message: '' };
    this.joinned = true;
    this.socket.on('save-message', { room: this.newUser.room, nickname: this.newUser.nickname, message: 'Join this room', updated_at: date });
  }
  sendMessage() {
    const data = {
      message: this.msg.message,
      
    };
        this.webSocketService.saveChat(data).subscribe(
          response => {
            this.getChatByRoom();
            console.log(response, 'response');
            
          },
          error => {
            console.log(error);
          });
          
        
  }
  logout() {
    var date = new Date();
    var user = JSON.parse(localStorage.getItem("user")|| '{}');
    this.socket.on('save-message', { room: user.room, nickname: user.nickname, message: 'Left this room', updated_at: date });
    localStorage.removeItem("user");
    this.joinned = false;
  }
  }


 




