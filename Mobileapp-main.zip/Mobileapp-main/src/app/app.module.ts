import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import { SignupComponent } from './signup/signup.component';
import {MatCardModule} from '@angular/material/card';
import {MatInputModule} from '@angular/material/input';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import {MatDialogModule} from '@angular/material/dialog';
import {MatTabsModule} from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { AdminComponent } from './admin/admin.component';
import { UserdashboardComponent } from './userdashboard/userdashboard.component';
import { MyserviceService } from './myservice.service';
import { HttpClientModule } from '@angular/common/http';
import { AddtocartComponent } from './addtocart/addtocart.component';
import {MatTableModule} from '@angular/material/table';
import { AdminadddetailsComponent } from './adminadddetails/adminadddetails.component';
import {MatGridListModule} from '@angular/material/grid-list';
import { ChatInboxComponent } from './chat-inbox/chat-inbox.component';
import { SmsNotificationComponent } from './sms-notification/sms-notification.component';









@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    SignupComponent,
    AdminComponent,
    UserdashboardComponent,
    AddtocartComponent,
    AdminadddetailsComponent,
    ChatInboxComponent,
    SmsNotificationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatInputModule,ReactiveFormsModule,FormsModule,
    MatDialogModule,MatTabsModule,MatFormFieldModule,HttpClientModule,
    MatTableModule,MatGridListModule

  ],
  providers: [MyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
