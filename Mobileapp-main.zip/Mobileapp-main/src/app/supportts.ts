export interface register
{
username:string,
emailid:string,
password:string,
mobilenumber:number,
isrole:string
}
export interface signin
{
    username:string,
    password:string

}
export interface tablevalue
{
    _id:string
    username:string,
    emailid:string,
    mobilenumber:number,
    isactive:boolean,
    isrole:string,
    action:string
}
export interface del
{
    _id:string
}


export interface admingetdetails
{
    mobileimg:string,
    mobilebrand:string,
    mobilemodel:string,
    mobileprice:string,
    mobileinternal:string,
    mobileexternal:string,
    mobilecolor:string
}
export interface displaymobiledetails
{

    mobileimg:string,
    mobilebrand:string,
    mobilemodel:string,
    mobileprice:string,
    mobileinternal:string,
    mobileexternal:string,
    mobilecolor:string

}
export interface chat
{
    _id: string;
    message: string;
}