import { Component, OnInit } from '@angular/core';
import * as Ably from 'ably';
@Component({
  selector: 'app-sms-notification',
  templateUrl: './sms-notification.component.html',
  styleUrls: ['./sms-notification.component.css']
})
export class SmsNotificationComponent implements OnInit {
from!: string;
text!: string;
timestamp!: string;
  constructor() { }

  ngOnInit() {
    let options: Ably.Types.ClientOptions = { key: '_59Bpg.XUBpZA:ZAroHdFT32gT2sKc' };
    let client = new Ably.Realtime(options);
    let channel = client.channels.get('sms-notification');

    channel.subscribe('new-sms', data => {
      this.smsNotifications.push(data.data);
    });
}

smsNotifications! :any [];
}
