
const mongoose = require('mongoose');
const passport = require('passport');
const _ = require('lodash');
const router = require('../router/index.router');
const { get, replace, values } = require('lodash');
const { authenticate } = require('passport');
const nodemailer = require('nodemailer');
const socket = require('socket.io');
const reg = mongoose.model('reg')
const Chatmessage = mongoose.model('chat');


const mob = mongoose.model('mobiledetails')



module.exports.mobileregister =async (req,res,next) =>
{
    try{

var regi = new reg();
regi.username=req.body.username;
regi.emailid=req.body.emailid;
regi.password=req.body.password;
regi.mobilenumber=req.body.mobilenumber;
regi.isrole=req.body.isrole;
    }catch{
regi.save(async(err,doc) => {
    if(!err) 
    {
        await main();
        console.log(doc)
        res.send(doc);
    }
    else
    {
        console.log(err);
    }
});
    }
}





async function main() {
    
    let testAccount = await nodemailer.createTestAccount();
  
    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
      host: "smtp.Ethereal.com",
      port: 587,
      secure: false, 
      auth: {
        user: testAccount.user, 
        pass: testAccount.pass, 
      },
    });
  
    // send mail with defined transport object
    let info = await transporter.sendMail({
      from: '"Fred Foo" <bhavya.c.318@gmail.com>', 
      to: "bhavya.c.318@gmail.com", 
      subject: "Hello ✔", 
      text: "Hello world?", 
      html: "<b>Hello world?</b>", 
    });
    console.log("Message sent: %s", info.messageId);
    console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
    return info;
  }
//   main().catch(console.error);




// async function sendMail(user, callback) {
//     // create reusable transporter object using the default SMTP transport
//     let transporter = nodemailer.createTransport({
//       host: "smtp.gmail.com",
//       port: 587,
//       secure: false, // true for 465, false for other ports
//       auth: {
//         user: "bhavya.c.318@gmail.com",
//         pass: "Bhavya@143"
//       }
//     });
  
//     let mailOptions = {
//         from: 'bhavya.c.318@gmail.com', // sender address
//         to: user.emailid, // list of receivers
//         subject: "Wellcome to Fun Of Heuristic ", // Subject line
//         html: `<h1>Hi ${user.name}</h1><br>
//         <h4>Thanks for joining us</h4>`
//       };
//     console.log("Message sent: %s", info.messageId);
//     // send mail with defined transport object
//     let info = await transporter.sendMail(mailOptions);
//     console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
//     callback(info);
// }



//     module.exports.sendmail =(req,res,next) =>{
//     console.log("request came");
//     let user = req.body;
   
    
//     sendMail(user, info => {
//       console.log(`The mail has beed send and the id is ${info.messageId}`);
//       res.send(info);
//     });
//   };
  

module.exports.authenticate =(req,res,next) =>
{
    
    passport.authenticate('local',(err,reg,info) => {

        if(err)
        return res.status(400).json(err);
        else if(reg,req)  
        {
        return res.status(200).json({"token":reg.generateJwt(),"_id":reg._id,"username":reg.username,"isrole":reg.isrole,"email":reg.emailid
    });
        }

        else
        return res.status(404).json(info);
    
    }) (req,res);
 

    
}


module.exports.userprofile=(req,res,next)=>
{
reg.findOne({_id:req._id},(err,value)=>
{
    console.log(req._id)
    if(!value)
    {
    return res.status(404).json({status:false,message:'User record not found'});
    }
    else{
        return res.status(200).json({status:true,value : _.pick(value,['username','emailid'])})
    }
})

}














module.exports.update = (req,res)=>
{
   
    reg.findOneAndUpdate({emailid:req.body.emailid},req.body,{new:true, useFindAndModify: false})
    .then(reg =>{
        if(!reg)
        {
            return res.status(404).json({
                msg:" customer email not found " + req.params.emailid
            });
        }
        res.json(reg);
    }).catch(err =>
    {
        if(err.kind ==='emailid')
        {
            return res.status(404).json({
                msg:" customer email not found " + req.params.emailid
            });

        }
        return res.status(500).json({
            msg:" error Updating Emailid " + req.params.emailid

        });
    }) ;
  
}



module.exports.getdbvalue =(req,res)=>
{
    reg.find({isrole:"user"}).
    then(reg => 
        {
            res.json(reg);

    }).catch(err =>
        {
            res.status(500).send({
                msg : err.message
            });
        });
}



module.exports.viewmobiledetails=(req,res)=>
{
    mob.find().then(mob =>
        {
            res.json(mob);
        }).catch(err =>
            
            {
                res.status(500).send({
                    msg : err.message
                });

            });
    
}


















module.exports.delete=(req,res)=>
{
    
    reg.findByIdAndRemove(req.body._id,{useFindAndModify:false})
    .then(data => {
        if(!data)
        {
            res.status(404).send({message :"ID not found"});

        }
        else
        {
            res.send({message:"data delete successfully"})
        }
    })
    .catch(err =>{
        res.status(500).send({message :" value could not delete"})
    })
}




module.exports.disable=(req,res) =>
{
    reg.findByIdAndRemove(req.body._id,{useFindAndModify:false})
    .then(data =>{
        if(!data)
        {
            res.status(404).send({message :"ID not found"});

        }
        else{
            res.send({message:"disable the users"})
        }

    }).catch(err=>
        {
            res.status(500).send({message :" value could not disable"})
        })

}



////admin side details





//Insert mobiledetails from admin


module.exports.mobledtl=(req,res,next)=>
{
    var mobile = new mob();

    mobile.mobileimg=req.body.mobileimg;
    mobile.mobilebrand=req.body.mobilebrand;
    mobile.mobilemodel=req.body.mobilemodel;
    mobile.mobileprice=req.body.mobileprice;
    mobile.mobileinternal=req.body.mobileinternal;
    mobile.mobileexternal=req.body.mobileexternal;
    mobile.mobileram=req.body.mobileram;
    mobile.mobilecolor=req.body.mobilecolor;


    mobile.save((err,doc) => {
        if(!err) 
        {
            console.log(doc)
            res.send(doc);
        }
        else
        {
            console.log(err);
        }
    });
}

// socket chat app 

module.exports.getchat = (req, res) => {
    const message = req.query.message;
    var condition = message ? { message: { $regex: new RegExp(message), $options: "i" } } : {};
  
    Chatmessage.find(condition)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving tutorials."
        });
      });
  };


  
module.exports.socketsending=(req,res,next)=>
{
  
    const chat = new Chatmessage({
        message: req.body.message,
      
      });
      chat
      .save(chat)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Tutorial."
        });
      });
  };
 

 




