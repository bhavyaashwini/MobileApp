require('./config/config');
require('./models/db');
require('./config/passportconfig'); 
const express = require('express');
 cors = require('cors');
var io = require('socket.io')(app);
var mongoose = require('mongoose');

const rtsIndex = require('./router/index.router');
const bodyParser = require('body-parser');
const passport =require('passport');
const nodemailer = require('nodemailer');


var app=express();

app.use(bodyParser.json());


console.log('app'); 

 app.use(passport.initialize());
 
io.on('connection', (socket)=>{
  console.log('a user connected');
});

var http = require('http').createServer(app);
var io = require('socket.io')(http);

// socket io
// io.on('connection', function(socket){
//   console.log("User Connected");
// socket.on('chat message', function(msg){
//   io.emit('chat message', msg);
//   console.log("Message");
// });
//  socket.on('disconnect', function(msg){
//   console.log("User DisConnected");
// });

// });
io.on('connection', function (socket) {
  console.log('User connected');
  socket.on('disconnect', function() {
    console.log('User disconnected');
  });
  socket.on('save-message', function (data) {
    console.log(data);
    io.emit('new-message', { message: data });
  });
});


app.get('/socket', (req, res)=> 
res.send('hello socket'));
app.use(cors());
app.use('/api',rtsIndex);

'/api/register'
'/api/authenticate'

app.listen(process.env.PORT,() => console.log(`server start PORT : ${process.env.PORT}`)); 

