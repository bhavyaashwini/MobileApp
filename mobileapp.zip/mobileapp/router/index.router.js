const express = require('express')
const router = express.Router();


const Ctrlreg =require('../controller/reg.controller');
const jwtHelper = require('../config/jwtHelper')

router.post('/mobileregister',Ctrlreg.mobileregister);
router.post('/authenticate',Ctrlreg.authenticate); 
router.put('/update',Ctrlreg.update);
router.get('/getdbvalue',Ctrlreg.getdbvalue);
router.post('/delete',Ctrlreg.delete);
router.post('/disable',Ctrlreg.disable);
router.post('/mobledtl',Ctrlreg.mobledtl);
// router.post('/sendmail',Ctrlreg.sendmail);

// get mobile details
router.get('/viewmobiledetails',Ctrlreg.viewmobiledetails)
// socket 
router.get('/getchat', Ctrlreg.getchat);
router.post('/socketsending', Ctrlreg.socketsending);


router.post('/mobiledtl',Ctrlreg.mobledtl)






module.exports =router;
console.log('ind');